﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Towers_of_Hanoi
{
    class Board
    {
        Disk[,] board; //condition says 2 dimentional array            
        ArrayList movements;
        Disk[] disks; //Array of disks
        int movesTarget;

        private const int NUM_DISKS = 4;
        private const int NUM_PEGS = 3;

        public Board()
        {
            board = new Disk[NUM_PEGS, NUM_DISKS];
            movements = new ArrayList();

            //Array of disk objects
            disks = new Disk[NUM_DISKS];
            disks[0] = null;
            disks[1] = null;
            disks[2] = null;
            disks[3] = null;

            //Storing disk object into board array(this is a 2 dimensional arrray) 
            board = new Disk[NUM_PEGS, NUM_DISKS]; // condition says 2 dimentional array  

            board[0, 3] = new Disk();
            board[0, 2] = new Disk();
            board[0, 1] = new Disk();
            board[0, 0] = new Disk();

            //Creating arraylist of movement 
            movements = new ArrayList();
        }

        //Alterntative constructor
        public Board(Disk d1, Disk d2, Disk d3, Disk d4, int movesTarget = 25)
        {
            //Storing into disks array
            disks = new Disk[NUM_DISKS];
            disks[0] = d1;
            disks[1] = d2;
            disks[2] = d3;
            disks[3] = d4;

            //Storing disk object into board array(This is a two dimensional arrray) 
            board = new Disk[NUM_PEGS, NUM_DISKS]; //condition says TWO dimentional array  
            board[0, 3] = d1;
            board[0, 2] = d2;
            board[0, 1] = d3;
            board[0, 0] = d4;

            this.movesTarget = movesTarget;

            //Arraylist of movement.
            movements = new ArrayList();
        }


        public void reset()
        {
            
        }


        public bool canStartMove(Disk aDisk)
        {
            return true;

        }

        // Checks if the move is legal.
        public bool canDrop(Disk aDisk, int aPeg)
        {

            return true;
        }


        public void move(Label aDisk, int newLevel)
        {
            Disk newDisk = FindDisk(aDisk);
            board[oldPeg, newDisk] = board.SetValue[newLevel, newDisk];
        }


        public string allMovesAsString()
        {
            return "dummy";  // Dummy return to avoid syntax error - must be changed
        }


        public void Display()
        {

        }

        // Finds the Disk ID number from the selected label.
        public Disk FindDisk(Label aLabel)
        {
            int aDiskID = Convert.ToInt32(aLabel.Text);
            Disk aDisk = disks[aDiskID - 1];
            return aDisk;
        }


        public int newLevInPeg(int pegNum)
        {
            return 1;    // Dummy return to avoid syntax error - must be changed
        }


        public String getText(int cnt)
        {
            return "1";    // Dummy return to avoid syntax error - must be changed
        }


        public void backToSelected(int ind)
        {

        }

        // Finds the ID number of the target peg.
        public int getPegInd(Panel aPeg)
        {
            int aPegID = Convert.ToInt32(aPeg.Name.Substring(7));
            return aPegID; 
        }


        public int getLevel(int ind)
        {
            return 1;    // Dummy return to avoid syntax error - must be changed
        }


        public void unDo()
        {

        }


        public void loadData(ArrayList dm)
        {

        }
    }
}