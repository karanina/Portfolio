﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

namespace Towers_of_Hanoi
{
    public class DiskMove
    {
        private string diskIDStr, pegNumStr;


        /// <summary>
        /// constuctor receiving integer parameters
        /// </summary>
        /// <param name="aDisk"></param>
        /// <param name="aPeg"></param>
        public DiskMove(Int32 aDisk, Int32 aPeg)
        {
            diskIDStr = aDisk.ToString();
            pegNumStr = aPeg.ToString();        
        }


        /// <summary> method:  OutputAsText
        /// provides string for output textbox 
        /// </summary>
        /// <returns></returns>
        public string OutputAsText()
        {
            string outputRecord = $"Disk {diskIDStr} has been moved to {pegNumStr}";
            return outputRecord;
        }

        /// <summary> method:  SaveAsText
        /// provides string for output textbox 
        /// </summary>
        /// <returns></returns>
        public string SaveAsText()
        {
            string outputRecord = $"[{diskIDStr},{pegNumStr}]/n/r";
            return outputRecord;
        }
    }
}
